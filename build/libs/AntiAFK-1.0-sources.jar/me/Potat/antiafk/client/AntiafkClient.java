package me.Potat.antiafk.client;

import com.mojang.brigadier.arguments.BoolArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import java.util.Random;

public class AntiafkClient implements ClientModInitializer {

    public static boolean enabled = false;
    private static final Random random = new Random();
    private static int movementDuration = 0; // ticks remaining for current random input
    private static final int MIN_DURATION = 20; // 1 second
    private static final int MAX_DURATION = 100; // 5 seconds

    @Override
    public void onInitializeClient() {
        registerCommands();
        registerEvents();
    }

    private void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(ClientCommandManager.literal("antiafk")
                .then(ClientCommandManager.argument("enabled", BoolArgumentType.bool())
                        .executes(context -> {
                            enabled = context.getArgument("enabled", Boolean.class);
                            class_310 client = class_310.method_1551();
                            if (client.field_1724 == null) {
                                context.getSource().sendError(class_2561.method_43470("You must be in a world to use this command."));
                                return 0;
                            }

                            if (enabled) {
                                movementDuration = 0; // start immediately
                                context.getSource().sendFeedback(class_2561.method_43470("Anti-AFK has been enabled."));
                            } else {
                                resetMovementKeys(client);
                                context.getSource().sendFeedback(class_2561.method_43470("Anti-AFK has been disabled."));
                            }
                            return 1;
                        }))));
    }

    private void registerEvents() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!enabled || client.field_1724 == null) {
                return;
            }

            if (movementDuration > 0) {
                movementDuration--;
                // keep current key state until duration ends
                // occasional small random jump while moving
                client.field_1690.field_1903.method_23481(random.nextInt(100) < 3);
                return;
            }

            // duration ended -> choose new random movement or a pause
            applyRandomMovement(client);
        });
    }

    private void applyRandomMovement(class_310 client) {
        // small chance to pause (no movement) for a short duration
        boolean pause = random.nextInt(100) < 15; // 15% chance to pause
        if (pause) {
            resetMovementKeys(client);
            movementDuration = MIN_DURATION + random.nextInt(40); // short pause
            return;
        }

        // Choose random combination of WASD. Avoid opposite pairs both true (W+S or A+D)
        boolean forward = random.nextInt(100) < 60; // 60% chance
        boolean back = !forward && (random.nextInt(100) < 25); // if not forward, small chance to go back
        boolean left = random.nextInt(100) < 35;
        boolean right = !left && (random.nextInt(100) < 35);

        // Occasionally strafe and move together
        if (!forward && !back && (random.nextInt(100) < 25)) {
            forward = true;
        }

        client.field_1690.field_1894.method_23481(forward);
        client.field_1690.field_1881.method_23481(back);
        client.field_1690.field_1913.method_23481(left);
        client.field_1690.field_1849.method_23481(right);

        // Randomly jump more often while moving
        client.field_1690.field_1903.method_23481(random.nextInt(100) < 15);

        movementDuration = MIN_DURATION + random.nextInt(MAX_DURATION - MIN_DURATION + 1);
    }

    private void resetMovementKeys(class_310 client) {
        client.field_1690.field_1894.method_23481(false);
        client.field_1690.field_1881.method_23481(false);
        client.field_1690.field_1913.method_23481(false);
        client.field_1690.field_1849.method_23481(false);
        client.field_1690.field_1903.method_23481(false);
        client.field_1690.field_1832.method_23481(false);
    }
}
